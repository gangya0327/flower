import * as historykeywords from './hkaction.js';
import * as cartaction from './cartaction.js';
export default {
    hk:historykeywords,
    cart:cartaction
}