/*eslint-disable*/
import React from 'react';
import Css from '../../../assets/css/home/index/index.css';
export default class  IndexComponent extends React.Component{
    componentDidMount(){

    }
    render(){
        return(
            <div>
                首页
            </div>
        );
    }
}