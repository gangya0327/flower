(function (globals) {
    globals.global={};
    //记录页面滚动的位置
    global.scrollTop = {
        index:0
    }
    module.exports = global;
})(window);