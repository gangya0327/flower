import React from 'react';
export default class  IndexComponent extends React.Component{
    componentDidMount(){

    }
    render(){
        return(
            <div>
                我的
            </div>
        );
    }
}