import React from 'react';
export default class  CartIndex extends React.Component{
    componentDidMount(){

    }
    render(){
        return(
            <div>
                购物车
            </div>
        );
    }
}