import * as historykeywords from './hkaction.js';
export default {
    hk:historykeywords
}